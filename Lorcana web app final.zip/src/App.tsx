/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Plus, 
  Trash2, 
  RotateCw, 
  FlipHorizontal, 
  MessageSquare, 
  FileJson, 
  ChevronRight,
  Hand,
  Trophy,
  Droplets,
  Eraser,
  Pen
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Constants ---
const TABLE_SIZE = 1600;
const CARD_W = 100;
const CARD_H = 139;

// Regions
const P1_HAND_Y = 1350;
const P2_HAND_Y_END = 250;

const INK_P1 = { x1: 0, y1: 1120, x2: 1600, y2: 1330 };
const INK_P2 = { x1: 0, y1: 270, x2: 1600, y2: 480 };

// --- Types ---
interface CardState {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation: number;
  faceUp: boolean;
  isInk: boolean;
  name: string;
  imageUrl: string;
  ownerId: string;
  playerRole?: 'p1' | 'p2';
}

interface ChatMessage {
  sender: string;
  text: string;
  timestamp: number;
}

export default function App() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomId, setRoomId] = useState<string>('default-lobby');
  const [cards, setCards] = useState<Record<string, CardState>>({});
  const [deck, setDeck] = useState<string[]>([]);
  const [chat, setChat] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [sharedNotes, setSharedNotes] = useState('');
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const [drawings, setDrawings] = useState<{x1: number, y1: number, x2: number, y2: number, color: string}[]>([]);
  const [myId] = useState(() => Math.random().toString(36).substring(7));
  const [myRole, setMyRole] = useState<'p1' | 'p2' | 'viewer'>('p1');
  const [onlinePlayers, setOnlinePlayers] = useState<string[]>([]);
  const [zoom, setZoom] = useState(0.7);

  const tableRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const currentDrawRef = useRef<{x: number, y: number} | null>(null);

  // Initialize Socket
  useEffect(() => {
    const s = io();
    setSocket(s);

    const currentRoom = new URLSearchParams(window.location.search).get('room') || 'default-lobby';
    setRoomId(currentRoom);

    s.emit('join-room', currentRoom);

    s.on('remote-action', (action: any) => {
      setCards(prev => {
        if (action.type === 'remove') {
          const newCards = { ...prev };
          delete newCards[action.id];
          return newCards;
        }
        return {
          ...prev,
          [action.id]: { ...(prev[action.id] || {}), ...action }
        };
      });
    });

    s.on('chat-relay', (msg: ChatMessage) => {
      setChat(prev => [...prev, msg]);
    });

    s.on('remote-draw', (draw: any) => {
      setDrawings(prev => [...prev, draw]);
    });

    s.on('room-state', (state: any) => {
      setCards(prev => ({ ...prev, ...state.cards }));
    });

    s.on('presence-update', (users: string[]) => {
      const unique = Array.from(new Set(users));
      setOnlinePlayers(unique);
    });

    return () => {
      s.disconnect();
    };
  }, []);

  // Heartbeat Effect
  useEffect(() => {
    if (!socket || !myId || !roomId) return;

    const interval = setInterval(() => {
      socket.emit('presence', { roomId, userId: myId });
    }, 2000);

    return () => clearInterval(interval);
  }, [socket, myId, roomId]);

  // Initialize Table View
  useEffect(() => {
    if (tableRef.current) {
      const container = tableRef.current.parentElement;
      if (container) {
        container.scrollTop = (myRole === 'p1' ? P1_HAND_Y : 0) * zoom - 100;
        container.scrollLeft = (TABLE_SIZE * zoom) / 2 - container.clientWidth / 2;
      }
    }
  }, [myRole, zoom]);

  // --- Actions ---

  const syncAction = useCallback((action: any) => {
    if (!socket) return;
    socket.emit('sync-action', { roomId, action });
  }, [socket, roomId]);

  const addCard = (imageUrl: string, name: string, x = 800, y = 800) => {
    const id = Math.random().toString(36).substring(7);
    const newCard: CardState = {
      id,
      x,
      y,
      w: CARD_W,
      h: CARD_H,
      rotation: 0,
      faceUp: true,
      isInk: false,
      name,
      imageUrl,
      ownerId: myId,
      playerRole: myRole
    };
    setCards(prev => ({ ...prev, [id]: newCard }));
    syncAction({ type: 'create', ...newCard });
  };

  const handleDrawCard = () => {
    if (deck.length === 0) {
      alert("Deck is empty!");
      return;
    }
    const [top, ...rest] = deck;
    setDeck(rest);
    // Draw into player's hand area
    const x = 300 + Math.random() * (TABLE_SIZE - 600);
    const y = myRole === 'p1' ? P1_HAND_Y + 50 : 50;
    addCard(top, "Unknown Card", x, y);
  };

  const nextTurn = () => {
    const updatedCards = { ...cards };
    Object.keys(updatedCards).forEach(id => {
      if (updatedCards[id].rotation !== 0) {
        updatedCards[id].rotation = 0;
        syncAction({ type: 'spin', id, rotation: 0 });
      }
    });
    setCards(updatedCards);
    sendChat("Ready all cards for my turn.");
  };

  const sendChat = (text: string) => {
    if (!text.trim()) return;
    const msg = { sender: 'Player', text, timestamp: Date.now() };
    setChat(prev => [...prev, msg]);
    socket?.emit('chat-message', { roomId, message: msg });
  };

  // --- TTS JSON Import ---
  const handleImportJson = (jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      const objectState = data.ObjectStates?.[0];
      if (!objectState) throw new Error("Invalid TTS format");

      const contained = objectState.ContainedObjects || [];
      const customDeck = objectState.CustomDeck || {};

      const newDeck: string[] = [];
      contained.forEach((obj: any) => {
        const deckId = Math.floor(obj.CardID / 100);
        const imageUrl = customDeck[deckId]?.FaceURL?.replace('?tts', '');
        if (imageUrl) {
          newDeck.push(imageUrl);
        }
      });

      if (newDeck.length === 0) throw new Error("No cards found in JSON");

      // Shuffle logic
      for (let i = newDeck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
      }

      setDeck(newDeck);
      alert(`Imported and shuffled ${newDeck.length} cards!`);
    } catch (e: any) {
      alert("Error importing: " + e.message);
    }
  };

  // --- Render Helpers ---

  const getVisibility = (card: CardState) => {
    // Identity check: Card is in hand if it's in a hand area
    const inP1Hand = card.y >= P1_HAND_Y;
    const inP2Hand = card.y <= P2_HAND_Y_END;
    
    // Privacy Logic:
    // 1. If card is Inked, Art is hidden from EVERYONE (standard engine request)
    if (card.isInk) return false;
    
    // 2. If card is in a hand area, only the owner can see the art
    if ((inP1Hand || inP2Hand) && card.ownerId !== myId) return false;
    
    // 3. Otherwise respect faceUp state
    return card.faceUp;
  };

  const handlePointerEvents = (e: React.MouseEvent) => {
    if (!isDrawingMode || !stageRef.current || myRole === 'viewer') return;
    
    const rect = stageRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / zoom;
    const y = (e.clientY - rect.top) / zoom;

    if (e.type === 'mousedown') {
      currentDrawRef.current = { x, y };
    } else if (e.type === 'mousemove' && currentDrawRef.current) {
      const newDraw = {
        x1: currentDrawRef.current.x,
        y1: currentDrawRef.current.y,
        x2: x,
        y2: y,
        color: '#4ade80'
      };
      setDrawings(prev => [...prev, newDraw]);
      socket?.emit('draw-event', { roomId, drawData: newDraw });
      currentDrawRef.current = { x, y };
    }
  };

  return (
    <div className="flex h-screen bg-[#0a0a0a] text-gray-100 overflow-hidden font-sans selection:bg-amber-500/30">
      {/* Sidebar */}
      <div className="w-80 border-r border-white/10 bg-[#111] flex flex-col shadow-2xl z-50">
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3 mb-1">
            <Trophy className="w-6 h-6 text-amber-500" />
            <h1 className="text-xl font-bold tracking-tight text-white uppercase italic">Lorcana VTT</h1>
          </div>
          <div className="flex flex-col gap-2 mt-3">
            <div className="flex items-center gap-4 mb-2 p-2 bg-white/5 rounded-lg border border-white/10">
              <span className="text-[10px] font-bold text-gray-500 uppercase">Role:</span>
              <div className="flex gap-2">
                <button 
                  onClick={() => setMyRole('p1')}
                  className={cn("px-3 py-1 rounded text-[10px] font-bold transition-all", myRole === 'p1' ? "bg-amber-500 text-black" : "bg-white/5 text-gray-400")}
                >
                  P1 (Bottom)
                </button>
                <button 
                  onClick={() => setMyRole('p2')}
                  className={cn("px-3 py-1 rounded text-[10px] font-bold transition-all", myRole === 'p2' ? "bg-amber-500 text-black" : "bg-white/5 text-gray-400")}
                >
                  P2 (Top)
                </button>
                <button 
                  onClick={() => setMyRole('viewer')}
                  className={cn("px-2 py-1 rounded text-[10px] font-bold transition-all", myRole === 'viewer' ? "bg-cyan-500 text-black" : "bg-white/5 text-gray-400")}
                >
                  Spectator
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold text-gray-500 uppercase">Room:</span>
              <input 
                value={roomId}
                onChange={(e) => {
                  const newRoom = e.target.value;
                  setRoomId(newRoom);
                  socket?.emit('join-room', newRoom);
                  // Update URL without reload
                  const url = new URL(window.location.href);
                  url.searchParams.set('room', newRoom);
                  window.history.pushState({}, '', url);
                }}
                className="bg-white/5 border border-white/10 rounded px-2 py-0.5 text-[10px] text-amber-400 focus:outline-none focus:border-amber-500/50 flex-1 font-mono"
              />
            </div>
            <button 
              onClick={() => {
                const url = window.location.href;
                navigator.clipboard.writeText(url);
              }}
              className="w-full py-1.5 px-3 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 border border-amber-500/20 rounded text-[10px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2"
            >
              <Users className="w-3 h-3" />
              Copy Invite Link (LAN/Online)
            </button>
          </div>
        </div>

        {/* Action Controls */}
        <div className="p-4 space-y-3 overflow-y-auto flex-1 custom-scrollbar">
          <button 
            onClick={nextTurn}
            disabled={myRole === 'viewer'}
            className={cn(
              "w-full py-3 px-4 rounded-lg font-bold flex items-center justify-center gap-2 transition-all active:scale-95 group",
              myRole === 'viewer' 
                ? "bg-gray-800/20 text-gray-600 border-gray-800/10 cursor-not-allowed opacity-50"
                : "bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border-emerald-500/30"
            )}
          >
            <RotateCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
            READY ALL (NEXT TURN)
          </button>

          <button 
            onClick={handleDrawCard}
            disabled={myRole === 'viewer'}
            className={cn(
              "w-full py-3 px-4 rounded-lg font-bold flex items-center justify-center gap-2 transition-all active:scale-95",
              myRole === 'viewer'
                ? "bg-gray-800/20 text-gray-600 border-gray-800/10 cursor-not-allowed opacity-50"
                : "bg-amber-600/20 hover:bg-amber-600/30 text-amber-400 border-amber-500/30"
            )}
          >
            <Plus className="w-4 h-4" />
            DRAW CARD ({deck.length})
          </button>

          <button 
            onClick={() => {
              if (myRole === 'viewer') return;
              const newDeck = [...deck];
              for (let i = newDeck.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
              }
              setDeck(newDeck);
              sendChat("Shuffled my deck.");
            }}
            disabled={myRole === 'viewer'}
            className={cn(
              "w-full py-2 px-4 border rounded-lg text-xs font-medium flex items-center justify-center gap-2 transition-all",
              myRole === 'viewer'
                ? "bg-gray-800/10 text-gray-700 border-gray-800/10 cursor-not-allowed opacity-50"
                : "bg-white/5 hover:bg-white/10 text-gray-300 border-white/10"
            )}
          >
            <Users className="w-3 h-3 text-gray-500" />
            SHUFFLE DECK
          </button>

          <div className="pt-4 border-t border-white/5 space-y-4">
            <div className="flex items-center justify-between px-1">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                <FileJson className="w-3 h-3" />
                Import Assets
              </span>
            </div>
            <textarea 
              readOnly={myRole === 'viewer'}
              placeholder={myRole === 'viewer' ? "Spectators cannot import assets" : "Paste Dreamborn JSON here..."}
              className={cn(
                "w-full h-32 bg-black/40 border border-white/10 rounded-lg p-3 text-[10px] font-mono focus:outline-none focus:border-amber-500/50 transition-colors resize-none",
                myRole === 'viewer' && "opacity-50 cursor-not-allowed"
              )}
              onChange={(e) => {
                if (myRole === 'viewer') return;
                if (e.target.value.includes('ObjectStates')) {
                  handleImportJson(e.target.value);
                  e.target.value = '';
                }
              }}
            />
          </div>

          <div className="pt-4 border-t border-white/5 space-y-2">
             <div className="flex items-center justify-between px-1">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
                <Users className="w-3 h-3" />
                Players Online ({onlinePlayers.length})
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {onlinePlayers.map((p, i) => (
                <div key={i} className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-[9px] text-emerald-400 font-mono">
                  {p === myId ? 'You' : `Player_${i}`}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Chat / Footer */}
        <div className="h-64 border-t border-white/10 bg-black/20 flex flex-col">
          <div className="flex-1 p-4 overflow-y-auto space-y-2 text-[10px] custom-scrollbar">
            {chat.map((m, i) => (
              <div key={i} className="flex gap-2">
                <span className="font-bold text-amber-500 shrink-0 capitalize">[{m.sender}]:</span>
                <span className="text-gray-400 break-words">{m.text}</span>
              </div>
            ))}
          </div>
          <div className="p-3 border-t border-white/5 flex gap-2">
            <input 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { sendChat(inputText); setInputText(''); } }}
              placeholder="Send message..."
              className="flex-1 bg-white/5 border border-white/10 rounded-md px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500/50"
            />
          </div>
        </div>
      </div>

      {/* Main Table Area */}
      <div className="flex-1 relative bg-[radial-gradient(circle_at_center,_#1a1a1a_0%,_#0a0a0a_100%)] overflow-auto custom-scrollbar group/table">
        {/* Stage Wrapper for Zoom */}
        <div 
          ref={tableRef}
          style={{ width: TABLE_SIZE * zoom, height: TABLE_SIZE * zoom }}
          className="relative origin-top-left transition-[width,height] duration-200"
        >
          {/* Inner Stage (the source at 1:1) */}
          <div 
            ref={stageRef}
            className="absolute inset-0 origin-top-left select-none"
            style={{ 
              transform: `scale(${zoom})`,
              width: TABLE_SIZE,
              height: TABLE_SIZE
            }}
            onMouseDown={handlePointerEvents}
            onMouseMove={handlePointerEvents}
            onMouseUp={() => currentDrawRef.current = null}
          >
            {/* Grid Background */}
            <div className="absolute inset-0 pointer-events-none opacity-5" 
              style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '100px 100px' }}
            />

            {/* Zones */}
            {/* P1 Inkwell */}
            <div 
              className="absolute border-y-2 border-dashed border-cyan-500/10 bg-gradient-to-r from-transparent via-cyan-500/[0.03] to-transparent flex items-center justify-center overflow-hidden"
              style={{ left: INK_P1.x1, top: INK_P1.y1, width: INK_P1.x2 - INK_P1.x1, height: INK_P1.y2 - INK_P1.y1 }}
            >
              <div className="flex items-center gap-20 whitespace-nowrap">
                {Array(5).fill(0).map((_, i) => (
                  <span key={i} className="text-cyan-500/10 font-black uppercase tracking-[0.8em] text-xl">Inkwell</span>
                ))}
              </div>
            </div>

            {/* P2 Inkwell */}
            <div 
              className="absolute border-y-2 border-dashed border-cyan-500/10 bg-gradient-to-r from-transparent via-cyan-500/[0.03] to-transparent flex items-center justify-center overflow-hidden"
              style={{ left: INK_P2.x1, top: INK_P2.y1, width: INK_P2.x2 - INK_P2.x1, height: INK_P2.y2 - INK_P2.y1 }}
            >
              <div className="flex items-center gap-20 whitespace-nowrap">
                {Array(5).fill(0).map((_, i) => (
                  <span key={i} className="text-cyan-500/10 font-black uppercase tracking-[0.8em] text-xl">Inkwell</span>
                ))}
              </div>
            </div>

            {/* Hand Areas */}
            <div 
              className="absolute border-b border-amber-500/10 bg-amber-500/[0.01] flex items-center justify-center"
              style={{ left: 0, top: 0, width: TABLE_SIZE, height: P2_HAND_Y_END }}
            >
              <span className="text-amber-500/10 font-black uppercase tracking-[0.4em] text-2xl">Player 2 Hand</span>
            </div>

            <div 
              className="absolute border-t border-amber-500/10 bg-amber-500/[0.01] flex items-center justify-center"
              style={{ left: 0, top: P1_HAND_Y, width: TABLE_SIZE, height: TABLE_SIZE - P1_HAND_Y }}
            >
              <span className="text-amber-500/10 font-black uppercase tracking-[0.4em] text-2xl">Player 1 Hand</span>
            </div>

            {/* Drawings */}
            <svg className="absolute inset-0 pointer-events-none w-full h-full">
              {drawings.map((d, i) => (
                <line key={i} x1={d.x1} y1={d.y1} x2={d.x2} y2={d.y2} stroke={d.color} strokeWidth="2" strokeLinecap="round" />
              ))}
            </svg>

            {/* Cards */}
            {Object.values(cards).map((card: CardState) => {
              const isVisible = getVisibility(card);
              const isOwner = card.ownerId === myId && myRole !== 'viewer';

              return (
                <motion.div
                  key={card.id}
                  drag={isOwner}
                  dragMomentum={false}
                  onDragEnd={(e, info) => {
                    if (!isOwner) return;
                    const deltaX = info.offset.x / zoom;
                    const deltaY = info.offset.y / zoom;
                    const newX = card.x + deltaX;
                    const newY = card.y + deltaY;
                    
                    let isInk = card.isInk;
                    let faceUp = card.faceUp;

                    // Check Inkwell Hits (Zone Detection Alg)
                    const inInkP1 = newX >= INK_P1.x1 && newX <= INK_P1.x2 && newY >= INK_P1.y1 && newY <= INK_P1.y2;
                    const inInkP2 = newX >= INK_P2.x1 && newX <= INK_P2.x2 && newY >= INK_P2.y1 && newY <= INK_P2.y2;

                    if (inInkP1 || inInkP2) {
                      isInk = true;
                      faceUp = false;
                    }

                    syncAction({ id: card.id, x: newX, y: newY, isInk, faceUp, type: 'move' });
                    setCards(prev => ({
                      ...prev,
                      [card.id]: { ...prev[card.id], x: newX, y: newY, isInk, faceUp }
                    }));
                  }}
                  initial={false}
                  animate={{
                    x: card.x,
                    y: card.y,
                    width: card.w || CARD_W,
                    height: card.h || CARD_H,
                    rotate: card.rotation,
                    scale: 1,
                  }}
                  transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                  className={cn(
                    "absolute cursor-grab active:cursor-grabbing rounded-md shadow-2xl hover:brightness-110 transition-all group",
                    card.isInk && "ring-2 ring-cyan-500 shadow-cyan-500/20"
                  )}
                  style={{ zIndex: 10 }}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    if (!isOwner) return;
                    const nextRot = card.rotation === 90 ? 0 : 90;
                    syncAction({ type: 'spin', id: card.id, rotation: nextRot });
                    setCards(prev => ({
                      ...prev,
                      [card.id]: { ...prev[card.id], rotation: nextRot }
                    }));
                  }}
                >
                  {isVisible ? (
                    <img 
                      src={card.imageUrl} 
                      alt={card.name}
                      className="w-full h-full object-cover rounded-md pointer-events-none"
                      draggable={false}
                    />
                  ) : (
                    <div className="w-full h-full bg-[#050505] border border-white/10 rounded-md flex items-center justify-center relative overflow-hidden shadow-inner">
                      <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent opacity-20" />
                      <div className="w-full h-full border-2 border-white/5 m-1 rounded flex items-center justify-center">
                        <Trophy className="w-8 h-8 text-white/10" />
                      </div>
                    </div>
                  )}
                  
                  {isOwner && (
                    <div className="absolute -top-10 left-0 right-0 flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/60 p-1 rounded-t-lg backdrop-blur-sm">
                      <button 
                        onClick={() => {
                          const nextRot = (card.rotation + 90) % 360;
                          syncAction({ type: 'spin', id: card.id, rotation: nextRot });
                          setCards(prev => ({ ...prev, [card.id]: { ...prev[card.id], rotation: nextRot } }));
                        }}
                        className="p-1 hover:bg-white/10 rounded text-sky-400"
                      >
                        <RotateCw className="w-3 h-3" />
                      </button>
                      <button 
                        onClick={() => {
                          const nextFace = !card.faceUp;
                          syncAction({ type: 'flip', id: card.id, faceUp: nextFace });
                          setCards(prev => ({ ...prev, [card.id]: { ...prev[card.id], faceUp: nextFace } }));
                        }}
                        className="p-1 hover:bg-white/10 rounded text-amber-400"
                      >
                        <FlipHorizontal className="w-3 h-3" />
                      </button>
                      <button 
                        onClick={() => {
                          // Return card to deck before removing
                          setDeck(prev => [...prev, card.imageUrl]);
                          sendChat("Returned a card to my deck.");
                          
                          syncAction({ type: 'remove', id: card.id });
                          setCards(prev => {
                            const n = { ...prev };
                            delete n[card.id];
                            return n;
                          });
                        }}
                        className="p-1 hover:bg-red-500/20 rounded text-red-500"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  {isOwner && (
                    <div 
                      className="absolute -bottom-1 -right-1 w-4 h-4 bg-amber-500 border border-white/20 rounded-sm cursor-nwse-resize z-[60] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        const startX = e.clientX;
                        const startY = e.clientY;
                        const startW = card.w || CARD_W;
                        const startH = card.h || CARD_H;

                        const onMouseMove = (moveEvent: MouseEvent) => {
                          const deltaX = (moveEvent.clientX - startX) / zoom;
                          const newW = Math.max(40, startW + deltaX);
                          const newH = newW * (CARD_H / CARD_W);
                          
                          setCards(prev => ({
                            ...prev,
                            [card.id]: { ...prev[card.id], w: newW, h: newH }
                          }));
                          syncAction({ type: 'resize', id: card.id, w: newW, h: newH });
                        };

                        const onMouseUp = () => {
                          window.removeEventListener('mousemove', onMouseMove);
                          window.removeEventListener('mouseup', onMouseUp);
                        };

                        window.addEventListener('mousemove', onMouseMove);
                        window.addEventListener('mouseup', onMouseUp);
                      }}
                    >
                      <div className="w-1 h-1 bg-white/40 rounded-full" />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Floating Tools Control Cluster */}
        <div className="fixed bottom-8 left-[340px] right-8 flex items-center justify-between pointer-events-none">
          <div className="flex items-center gap-2 p-2 bg-[#1a1a1a] border border-white/10 rounded-full shadow-2xl backdrop-blur-md pointer-events-auto">
            <button 
              onClick={() => setIsDrawingMode(!isDrawingMode)}
              className={cn(
                "p-3 rounded-full transition-all",
                isDrawingMode ? "bg-emerald-600 text-white" : "hover:bg-white/5 text-gray-400"
              )}
            >
              <Pen className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setDrawings([])}
              className="p-3 bg-red-600/10 hover:bg-red-600/20 text-red-500 rounded-full transition-all"
            >
              <Eraser className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-4 p-2 bg-[#1a1a1a] border border-white/10 rounded-full shadow-2xl backdrop-blur-md pointer-events-auto">
            <span className="text-[10px] font-black text-gray-600 uppercase ml-4 tracking-[0.2em]">Scale: {Math.round(zoom * 100)}%</span>
            <div className="flex items-center gap-1">
              <button 
                onClick={() => setZoom(prev => Math.max(0.4, prev - 0.1))}
                className="w-10 h-10 flex items-center justify-center hover:bg-white/5 text-gray-400 rounded-full"
              >
                -
              </button>
              <button 
                onClick={() => setZoom(1.0)}
                className="px-3 py-1 bg-white/5 hover:bg-white/10 text-gray-300 rounded-md text-[10px] font-bold"
              >
                100%
              </button>
              <button 
                onClick={() => setZoom(prev => Math.min(1.5, prev + 0.1))}
                className="w-10 h-10 flex items-center justify-center hover:bg-white/5 text-gray-400 rounded-full"
              >
                +
              </button>
            </div>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255,255,255,0.2);
        }
      `}} />
    </div>
  );
}

import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
    },
  });

  const PORT = 3000;

  // Track simple game state per room
  const rooms = new Map<string, any>();
  const presences = new Map<string, Set<string>>();

  io.on("connection", (socket) => {
    console.log("User connected", socket.id);

    socket.on("join-room", (roomId) => {
      socket.join(roomId);
      if (!presences.has(roomId)) presences.set(roomId, new Set());
      console.log(`User ${socket.id} joined room ${roomId}`);
      
      if (rooms.has(roomId)) {
        socket.emit("room-state", rooms.get(roomId));
      }
    });

    socket.on("presence", ({ roomId, userId }) => {
      if (!presences.has(roomId)) presences.set(roomId, new Set());
      presences.get(roomId)?.add(userId);
      io.to(roomId).emit("presence-update", Array.from(presences.get(roomId) || []));
    });

    socket.on("sync-action", ({ roomId, action }) => {
      // Simple relay
      socket.to(roomId).emit("remote-action", action);
      
      // Update persistent state (optional but good for reconnects)
      if (!rooms.has(roomId)) {
        rooms.set(roomId, { cards: {}, players: {} });
      }
      const state = rooms.get(roomId);
      
      if (action.type === 'move' || action.type === 'spin' || action.type === 'flip' || action.type === 'inkwell') {
        state.cards[action.id] = { ...state.cards[action.id], ...action };
      }
    });

    socket.on("chat-message", ({ roomId, message }) => {
      socket.to(roomId).emit("chat-relay", message);
    });

    socket.on("draw-event", ({ roomId, drawData }) => {
      socket.to(roomId).emit("remote-draw", drawData);
    });

    socket.on("disconnect", () => {
      // Optional: Clear presences after some time if room is empty
      console.log("User disconnected", socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
